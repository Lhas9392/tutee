
<?php
require "../db_connect.php";

$message = "";

// Temporary tutee ID
$tuteeId = "TE0001";

// Handle tutor requests
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $tutorId = trim($_POST["tutor_id"] ?? "");

    // Check if the tutee exists
    $stmt = $conn->prepare(
        "SELECT tutee_id FROM tutee WHERE tutee_id = ?"
    );

    $stmt->bind_param("s", $tuteeId);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 0) {
        $message = "Tutee not found.";
    }

    $stmt->close();

    // Check if the tutor exists
    if ($message === "") {

        $stmt = $conn->prepare(
            "SELECT tutor_id FROM tutor WHERE tutor_id = ?"
        );

        $stmt->bind_param("s", $tutorId);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 0) {
            $message = "Tutor not found.";
        }

        $stmt->close();
    }

    // Prevent tutors from requesting themselves
    if ($message === "") {

        $sql = "SELECT 1
                FROM tutee te
                JOIN tutor tu
                ON LOWER(TRIM(te.first_name)) =
                   LOWER(TRIM(tu.first_name))
                AND LOWER(TRIM(te.last_name)) =
                    LOWER(TRIM(tu.last_name))
                WHERE te.tutee_id = ?
                AND tu.tutor_id = ?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $tuteeId, $tutorId);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $message = "You cannot request yourself as a tutor.";
        }

        $stmt->close();
    }

    // Prevent duplicate ACTIVE requests
    // Allow new requests after acknowledgement or connection
    if ($message === "") {

        $sql = "SELECT request_id
                FROM requests
                WHERE tutee_id = ?
                AND tutor_id = ?
                AND (
                    LOWER(request_status) = 'pending'

                    OR (
                        LOWER(request_status) = 'denied'
                        AND acknowledged = 0
                    )

                    OR (
                        LOWER(request_status) = 'approved'
                        AND tutee_connected = 0
                    )
                )";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $tuteeId, $tutorId);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $message = "You already have an active request for this tutor.";
        }

        $stmt->close();
    }

    // Submit new request
    if ($message === "") {

        $sql = "INSERT INTO requests
                (tutee_id, tutor_id,
                 request_date, request_status)
                VALUES (?, ?, CURRENT_TIMESTAMP, 'pending')";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $tuteeId, $tutorId);

        try {
            $stmt->execute();
            $message = "Tutor request submitted successfully!";
        } catch (mysqli_sql_exception $e) {
            $message = "Could not submit the request.";
        }

        $stmt->close();
    }
}

// Retrieve all tutors directly from MySQL
$sql = "SELECT tutor_id,
               first_name,
               last_name,
               years_of_experience,
               area_of_expertise
        FROM tutor
        ORDER BY last_name, first_name";

$result = $conn->query($sql);

// Tutor photos
$photos = [
    "TR0001" => "mcqueen.webp",
    "TR0002" => "white.webp",
    "TR0003" => "scoob.webp",
    "TR0004" => "mj.webp",
    "TR0005" => "batman.webp"
];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Meet Our Tutors | Tutee</title>

    <link rel="stylesheet" href="style.css">

    <style>
        .tutor-list {
            display: grid;
            grid-template-columns:
                repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            padding: 20px 0;
        }

        .tutor-card {
            background: white;
            color: #222;
            padding: 24px;
            border-radius: 12px;
            box-shadow: 0 2px 8px #0001;
            overflow: hidden;
        }

        .tutor-photo {
            display: block;
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 10px;
        }

        .tutor-card h2 {
            margin-top: 12px;
        }

        .tutor-card form button {
            display: block;
            width: 100%;
            margin-top: 16px;
            padding: 12px 18px;
            border: none;
            border-radius: 999px;
            background: var(--teal, #168b83);
            color: white;
            font-family: inherit;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
        }

        .tutor-card form button:hover {
            background: var(--teal-dark, #11645e);
            color: white;
        }

        .request-message {
            padding: 15px;
            margin: 20px 0;
            background: #e8f5f3;
            color: #155e55;
            border-radius: 8px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<header class="site-header">

    <nav class="navbar">

        <a href="index.html" class="logo">
            tutee<span>.</span>
        </a>

        <ul class="nav-links">

            <li><a href="index.html">Home</a></li>

            <li><a href="sign-up.html">Sign Up</a></li>

            <li><a href="sign-in.html">Sign In</a></li>

            <li>
                <a href="become-a-tutor.html">
                    Become a Tutor
                </a>
            </li>

            <li>
                <a href="tutors.php" class="active">
                    Meet Our Tutors
                </a>
            </li>

            <li>
                <a href="contact-us.html">
                    Contact Us
                </a>
            </li>

            <li>
                <a href="requests.php">
                    Requests
                </a>
            </li>

        </ul>

    </nav>

</header>

<main class="section">

    <h1>Meet Our Tutors!</h1>

    <?php if ($message !== ""): ?>

        <p class="request-message">
            <?php echo htmlspecialchars($message); ?>
        </p>

    <?php endif; ?>

    <p class="section-intro">
        Find experienced peers who can help you succeed.
    </p>

    <div class="tutor-list">

        <?php if ($result && $result->num_rows > 0): ?>

            <?php while ($row = $result->fetch_assoc()): ?>

                <?php
                $tutorId = $row["tutor_id"];
                ?>

                <article class="tutor-card">

                    <?php if (isset($photos[$tutorId])): ?>

                        <img
                            class="tutor-photo"
                            src="<?php
                                echo htmlspecialchars(
                                    $photos[$tutorId]
                                );
                            ?>"
                            alt="Tutor photo">

                    <?php endif; ?>

                    <h2>
                        <?php
                        echo htmlspecialchars(
                            $row["first_name"] . " " .
                            $row["last_name"]
                        );
                        ?>
                    </h2>

                    <p>
                        <strong>Tutor ID:</strong>
                        <?php echo htmlspecialchars($tutorId); ?>
                    </p>

                    <p>
                        <strong>Area of Expertise:</strong>
                        <?php
                        echo htmlspecialchars(
                            $row["area_of_expertise"]
                        );
                        ?>
                    </p>

                    <p>
                        <strong>Years of Experience:</strong>
                        <?php
                        echo htmlspecialchars(
                            $row["years_of_experience"]
                        );
                        ?>
                    </p>

                    <form method="POST" action="tutors.php">

                        <input
                            type="hidden"
                            name="tutor_id"
                            value="<?php
                                echo htmlspecialchars($tutorId);
                            ?>">

                        <button type="submit">
                            Request This Tutor
                        </button>

                    </form>

                </article>

            <?php endwhile; ?>

        <?php else: ?>

            <p>No tutors found in the database.</p>

        <?php endif; ?>

    </div>

</main>

</body>
</html>

<?php
$conn->close();
?>
