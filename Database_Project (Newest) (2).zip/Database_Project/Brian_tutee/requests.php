
<?php
require "../db_connect.php";

$message = "";
$tuteeId = "TE0001";

// Handle request actions
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $requestId = (int) ($_POST["request_id"] ?? 0);
    $action = $_POST["action"] ?? "";

    if ($requestId > 0) {

        // APPROVE OR DENY
        if (in_array($action, ["approved", "denied"], true)) {

            $sql = "UPDATE requests
                    SET request_status = ?
                    WHERE request_id = ?
                    AND LOWER(request_status) = 'pending'";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $action, $requestId);

            try {
                $stmt->execute();

                if ($stmt->affected_rows > 0) {
                    $message = "Request has been " . $action . "!";
                } else {
                    $message = "Request could not be updated.";
                }

            } catch (mysqli_sql_exception $e) {
                $message = "Error updating request.";
            }

            $stmt->close();
        }

        // ACKNOWLEDGE DENIED REQUEST
        elseif ($action === "acknowledge") {

            $sql = "UPDATE requests
                    SET acknowledged = 1
                    WHERE request_id = ?
                    AND tutee_id = ?
                    AND LOWER(request_status) = 'denied'
                    AND acknowledged = 0";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param("is", $requestId, $tuteeId);

            try {
                $stmt->execute();

                if ($stmt->affected_rows > 0) {
                    $message = "Denied request acknowledged!";
                } else {
                    $message = "Request could not be acknowledged.";
                }

            } catch (mysqli_sql_exception $e) {
                $message = "Error acknowledging request.";
            }

            $stmt->close();
        }

        // TUTOR CLICKS CONNECT WITH TUTEE
        elseif ($action === "tutor_connect") {

            $sql = "UPDATE requests
                    SET tutor_connected = 1
                    WHERE request_id = ?
                    AND LOWER(request_status) = 'approved'
                    AND tutor_connected = 0";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $requestId);

            try {
                $stmt->execute();

                if ($stmt->affected_rows > 0) {
                    $message = "Tutee connection confirmed!";
                } else {
                    $message = "Connection could not be updated.";
                }

            } catch (mysqli_sql_exception $e) {
                $message = "Error updating connection.";
            }

            $stmt->close();
        }

        // TUTEE CLICKS CONNECT WITH TUTOR
        elseif ($action === "tutee_connect") {

            $sql = "UPDATE requests
                    SET tutee_connected = 1
                    WHERE request_id = ?
                    AND tutee_id = ?
                    AND LOWER(request_status) = 'approved'
                    AND tutee_connected = 0";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param("is", $requestId, $tuteeId);

            try {
                $stmt->execute();

                if ($stmt->affected_rows > 0) {
                    $message = "Tutor connection confirmed!";
                } else {
                    $message = "Connection could not be updated.";
                }

            } catch (mysqli_sql_exception $e) {
                $message = "Error updating connection.";
            }

            $stmt->close();
        }
    }
}

// INCOMING REQUESTS FOR ALL TUTORS
// Hide acknowledged denials and tutor-connected approvals
$sql = "SELECT r.request_id,
               r.tutee_id,
               r.tutor_id,
               r.request_date,
               r.request_status,
               te.first_name AS tutee_first,
               te.last_name AS tutee_last,
               tu.first_name AS tutor_first,
               tu.last_name AS tutor_last
        FROM requests r
        JOIN tutee te
            ON r.tutee_id = te.tutee_id
        JOIN tutor tu
            ON r.tutor_id = tu.tutor_id
        WHERE NOT (
            LOWER(r.request_status) = 'denied'
            AND r.acknowledged = 1
        )
        AND NOT (
            LOWER(r.request_status) = 'approved'
            AND r.tutor_connected = 1
        )
        ORDER BY r.request_date DESC,
                 r.request_id DESC";

$tutorRequests = $conn->query($sql);

// MY TUTOR REQUESTS
// Hide acknowledged denials and tutee-connected approvals
$sql = "SELECT r.request_id,
               r.tutor_id,
               r.request_date,
               r.request_status,
               t.first_name,
               t.last_name
        FROM requests r
        JOIN tutor t
            ON r.tutor_id = t.tutor_id
        WHERE r.tutee_id = ?
        AND NOT (
            LOWER(r.request_status) = 'denied'
            AND r.acknowledged = 1
        )
        AND NOT (
            LOWER(r.request_status) = 'approved'
            AND r.tutee_connected = 1
        )
        ORDER BY r.request_date DESC,
                 r.request_id DESC";

$myStmt = $conn->prepare($sql);
$myStmt->bind_param("s", $tuteeId);
$myStmt->execute();

$myRequests = $myStmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Requests | Tutee</title>

    <link rel="stylesheet" href="style.css">

    <style>
        .request-section {
            margin-top: 35px;
        }

        .request-section h2 {
            margin-bottom: 12px;
        }

        .request-card {
            background: white;
            color: #222;
            padding: 24px;
            margin: 16px 0;
            border-radius: 14px;
            box-shadow: 0 2px 8px #0001;
        }

        .request-card h3 {
            color: var(--teal, #168b83);
            margin-bottom: 8px;
        }

        .request-card p {
            margin: 8px 0;
        }

        .request-status {
            font-weight: 700;
            margin: 12px 0;
        }

        .request-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 16px;
        }

        .request-actions button {
            padding: 10px 18px;
            border: none;
            border-radius: 999px;
            cursor: pointer;
            font-weight: 700;
            color: white;
            font-family: inherit;
            font-size: 1rem;
        }

        .approve {
            background: #16834a;
        }

        .deny {
            background: #a83232;
        }

        .acknowledge {
            background: #555;
        }

        .connect {
            background: var(--teal, #168b83);
        }

        .request-actions button:hover {
            opacity: 0.85;
            color: white;
        }

        .status-approved {
            color: #16834a;
        }

        .status-denied {
            color: #a83232;
        }

        .status-pending {
            color: #a36b00;
        }

        .request-message {
            background: #e8f5f3;
            color: #155e55;
            padding: 15px;
            margin: 20px 0;
            border-radius: 8px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<header class="site-header">

    <nav class="navbar">

        <a href="index.html" class="logo">
            tutee<span>.</span>
        </a>

        <ul class="nav-links">
            <li><a href="index.html">Home</a></li>
            <li><a href="sign-up.html">Sign Up</a></li>
            <li><a href="sign-in.html">Sign In</a></li>
            <li><a href="become-a-tutor.html">Become a Tutor</a></li>
            <li><a href="tutors.php">Meet Our Tutors</a></li>
            <li><a href="contact-us.html">Contact Us</a></li>
            <li><a href="requests.php" class="active">Requests</a></li>
        </ul>

    </nav>

</header>

<main class="section">

    <h1>Requests</h1>

    <?php if ($message !== ""): ?>
        <p class="request-message">
            <?php echo htmlspecialchars($message); ?>
        </p>
    <?php endif; ?>

    <!-- INCOMING REQUESTS -->

    <section class="request-section">

        <h2>Incoming Requests</h2>

        <p>View and manage requests sent to tutors.</p>

        <?php if ($tutorRequests->num_rows > 0): ?>

            <?php while ($request = $tutorRequests->fetch_assoc()): ?>

                <?php
                $status = strtolower($request["request_status"]);
                $tuteeName = $request["tutee_first"] . " " .
                             $request["tutee_last"];
                $tutorName = $request["tutor_first"] . " " .
                             $request["tutor_last"];
                ?>

                <article class="request-card">

                    <h3>
                        <?php echo htmlspecialchars($tuteeName); ?>
                    </h3>

                    <p>
                        <strong>Requested Tutor:</strong>
                        <?php echo htmlspecialchars($tutorName); ?>
                    </p>

                    <p>
                        <strong>Tutee ID:</strong>
                        <?php echo htmlspecialchars($request["tutee_id"]); ?>
                    </p>

                    <p>
                        <strong>Tutor ID:</strong>
                        <?php echo htmlspecialchars($request["tutor_id"]); ?>
                    </p>

                    <p>
                        <strong>Request Date:</strong>
                        <?php echo htmlspecialchars($request["request_date"]); ?>
                    </p>

                    <p class="request-status status-<?php
                        echo htmlspecialchars($status);
                    ?>">
                        Status:
                        <?php echo htmlspecialchars(ucfirst($status)); ?>
                    </p>

                    <!-- APPROVE AND DENY -->

                    <?php if ($status === "pending"): ?>

                        <form method="POST" class="request-actions">

                            <input
                                type="hidden"
                                name="request_id"
                                value="<?php echo (int) $request["request_id"]; ?>">

                            <button
                                class="approve"
                                type="submit"
                                name="action"
                                value="approved">
                                Approve
                            </button>

                            <button
                                class="deny"
                                type="submit"
                                name="action"
                                value="denied">
                                Deny
                            </button>

                        </form>

                    <?php endif; ?>

                    <!-- TUTOR CONNECTS WITH TUTEE -->

                    <?php if ($status === "approved"): ?>

                        <form method="POST" class="request-actions">

                            <input
                                type="hidden"
                                name="request_id"
                                value="<?php echo (int) $request["request_id"]; ?>">

                            <button
                                class="connect"
                                type="submit"
                                name="action"
                                value="tutor_connect">

                                Connect with
                                <?php
                                echo htmlspecialchars(
                                    $request["tutee_first"]
                                );
                                ?>

                            </button>

                        </form>

                    <?php endif; ?>

                </article>

            <?php endwhile; ?>

        <?php else: ?>

            <p>No incoming requests found.</p>

        <?php endif; ?>

    </section>

    <hr>

    <!-- MY TUTOR REQUESTS -->

    <section class="request-section">

        <h2>My Tutor Requests</h2>

        <p>View the status of your submitted requests.</p>

        <?php if ($myRequests->num_rows > 0): ?>

            <?php while ($request = $myRequests->fetch_assoc()): ?>

                <?php
                $status = strtolower($request["request_status"]);
                ?>

                <article class="request-card">

                    <h3>
                        <?php
                        echo htmlspecialchars(
                            $request["first_name"] . " " .
                            $request["last_name"]
                        );
                        ?>
                    </h3>

                    <p>
                        <strong>Tutor ID:</strong>
                        <?php echo htmlspecialchars($request["tutor_id"]); ?>
                    </p>

                    <p>
                        <strong>Request Date:</strong>
                        <?php echo htmlspecialchars($request["request_date"]); ?>
                    </p>

                    <p class="request-status status-<?php
                        echo htmlspecialchars($status);
                    ?>">
                        Status:
                        <?php echo htmlspecialchars(ucfirst($status)); ?>
                    </p>

                    <!-- ACKNOWLEDGE DENIED REQUEST -->

                    <?php if ($status === "denied"): ?>

                        <p>
                            Your tutor request was denied.
                            Please acknowledge this response.
                        </p>

                        <form method="POST" class="request-actions">

                            <input
                                type="hidden"
                                name="request_id"
                                value="<?php echo (int) $request["request_id"]; ?>">

                            <button
                                class="acknowledge"
                                type="submit"
                                name="action"
                                value="acknowledge">
                                Acknowledge
                            </button>

                        </form>

                    <?php endif; ?>

                    <!-- TUTEE CONNECTS WITH TUTOR -->

                    <?php if ($status === "approved"): ?>

                        <form method="POST" class="request-actions">

                            <input
                                type="hidden"
                                name="request_id"
                                value="<?php echo (int) $request["request_id"]; ?>">

                            <button
                                class="connect"
                                type="submit"
                                name="action"
                                value="tutee_connect">

                                Connect with
                                <?php
                                echo htmlspecialchars(
                                    $request["first_name"]
                                );
                                ?>

                            </button>

                        </form>

                    <?php endif; ?>

                </article>

            <?php endwhile; ?>

        <?php else: ?>

            <p>You have no active tutor requests.</p>

        <?php endif; ?>

    </section>

</main>

<footer class="site-footer">

    <a href="index.html" class="logo">
        tutee<span>.</span>
    </a>

    <p>
        Peer tutoring for Virginia State University students.
    </p>

    <p>&copy; 2026 Tutee</p>

</footer>

</body>
</html>

<?php
$myStmt->close();
$conn->close();
?>
